 <?php require 'tabs.php'; ?> <!--including tabs file -->
<body>
<ul class="nav nav-tabs">
    <?php echo $category_html; ?>
</ul>
<div class="tab-content">
    <?php echo $product_html; ?>
</div>
<!-- button to call the function -->
<a href="#myDIV"><button class="setting" onclick="myFunction()">Click to add more</button></a>
<div style="display: none;" id="myDIV">
<?php require 'form.php'; ?> 
</div>
<!-- to call the search form function -->
<script>
    function myFunction() {
        var x = document.getElementById("myDIV");
        if (x.style.display === "none") {
            x.style.display = "block";
        } else {
            x.style.display = "none";
        }
    }
</script>
</body>
</html>
