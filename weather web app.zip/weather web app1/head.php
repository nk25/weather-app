<!DOCTYPE html>
<html>
	<head>
		<link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" rel="stylesheet">
 		<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
		<!-- <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" /> -->
		<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />		
		<script src="http://code.jquery.com/jquery-2.1.4.min.js"></script>
		<script type="text/javascript" src="js/typeahead.js"></script>
		<script type="text/javascript" src="typeahead.js"></script>	
		<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css"> -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
		<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script> -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	</head>