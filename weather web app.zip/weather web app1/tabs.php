<?php
require 'head.php';  //including head file
require 'config.php'; // including config file

 //diffentiating user on the basis of ip address 
$user_ip      = getenv('REMOTE_ADDR');

//for creating the dynamic tabs 
$category_sql = "SELECT * FROM search_cities where ip='".$user_ip."' order by id desc";
$resultset = mysqli_query($connect, $category_sql) or die("database error:" . mysqli_error($connect));
$active_class  = 0;
$category_html = '';
$product_html  = '';
while ($category = mysqli_fetch_assoc($resultset)) {
    $current_tab     = "";
    $current_content = "";
    if (!$active_class) {
        $active_class    = 1;
        $current_tab     = 'active';
        $current_content = 'in active';
    }
    $category_html .= '<li class="' . $current_tab . '"><a href="#' . $category['id'] . '" data-toggle="tab">' . $category['city_name'] . '</a></li>';
    $product_html .= '<div id="' . $category["id"] . '" class="tab-pane fade ' . $current_content . '">';
    $product_sql = "SELECT * FROM search_cities WHERE id = " . $category["id"];
    $product_results = mysqli_query($connect, $product_sql) or die("database error:" . mysqli_error($connect));
    if (!mysqli_num_rows($product_results)) {
        $product_html .= '<br>No product found!';
    }
    while ($product = mysqli_fetch_assoc($product_results)) {  
        $category_sql1 = "SELECT * FROM weather_image where weather_type='" . $product['weather'] . "'";
        $resultset1 = mysqli_query($connect, $category_sql1) or die("database error:" . mysqli_error($connect));    
        while ($category1 = mysqli_fetch_assoc($resultset1)) {
            $product_html .= '<img style="height:200px" src="images/' . $category1['image'] . '" /><br>';           
            $product_html .= '<div class="col-md-3 product">';
            $product_html .= '<form action="formsubmit.php" class="" method="post"';  

            $product_html .= '<h4>Country Name:</h4>';           
            $id = $product['id'];            
            $product_html .= '<input type="hidden" name="id" value="' . $id . '" id="txtCountry" class="typeahead"/><br>';    
            $product_html .= '<input type="text" name="country" value="' . $product['country'] . '" id="txtCountry" class="typeahead"/><br>';
            
            $product_html .= '<h4>State Name:</h4>';
            $product_html .= '<input type="text" name="country" value="' . $product['state'] . '" id="txtCountry" class="typeahead"/>';
            
            $product_html .= '<h4>City Name:</h4>';
            $product_html .= '<input type="text" name="country" value="' . $product['city_name'] . '" id="txtCountry" class="typeahead"/>';
            
            $product_html .= '<h4>Temperature:</h4>';
            $product_html .= '<input type="text" name="country" value="' . $product['temp'] . '" id="txtCountry" class="typeahead"/><br>';
            
            $product_html .= '<h4>Weather:</h4>';
            $product_html .= '<input type="text" name="country" value="' . $product['weather'] . '" id="txtCountry" class="typeahead"/><br>';
            $product_html .= '<input type="submit" value="delete" name="delete">';
            
            $product_html .= '</form>';
            
            $product_html .= '</div>';
        }
        $product_html .= '<div class="clear_both"></div></div>';
    }
}
?>