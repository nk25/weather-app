<?php
require 'config.php'; // for the connection of database
if (isset($_POST['submit'])) {
    $city         = $_POST['city'];
    $country      = $_POST['country'];

    // wunderground api
    $app_url      = "http://api.wunderground.com/api/074be284703bdbe1/geolookup/conditions/forecast/q/" . $country . "/" . $city . ".json";

    $weather_data = file_get_contents($app_url);
    $json         = json_decode($weather_data, TRUE);
    // to check user ip address
    $user_ip      = getenv('REMOTE_ADDR');
    $geo          = unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip=$user_ip"));
    $city         = $geo["geoplugin_city"];
    $region       = $geo["geoplugin_regionName"];
    $country      = $geo["geoplugin_countryName"];
    $res          = file_get_contents('https://www.iplocate.io/api/lookup/150.242.65.155');
    $res          = json_decode($res, TRUE);
    $country      = $res['country'];    
    $cntry_name = $json['location']['country_name'];
    $city_name  = $json['location']['city'];

   	 // getting the location of user to show the temperature accourding to him
    if ($country == "India") {
        $temp = $json['current_observation']['temp_c'];
    } else {
        $temp = $json['current_observation']['temp_c'];
    }
    $state   = $json['location']['state'];
    $weather = $json['current_observation']['weather'];
    $addqry  = "INSERT INTO search_cities( `city_name`, `country`, `temp`, `state`, `weather`,`ip`) VALUES ('" . $city_name . "','" . $cntry_name . "','" . $temp . "','" . $state . "','" . $weather . "','" . $user_ip . "')";
    $addrun  = mysqli_query($connect, $addqry);

    // setting the cokkies
    setcookie('mycookie[search_city]', $city_name, time() + (10 * 365 * 24 * 60 * 60), '/');
    setcookie('mycookie[searched_country]', $cntry_name, time() + (10 * 365 * 24 * 60 * 60), '/');
    // setcookie('mycookie[state]', $state, time() + (10 * 365 * 24 * 60 * 60), '/');
    header('Location:weather.php');
}
// for the deletion of tabes
if (isset($_POST['delete'])) {
    extract($_POST);
    $addqry = "DELETE FROM `search_cities` WHERE id=" . $id;
    $addrun = mysqli_query($connect, $addqry);
    echo '<script>window.alert("Deleted");window.location.href="weather.php";</script>';
}
?>