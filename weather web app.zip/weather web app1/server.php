<?php
include "config.php";
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
// Check connection
// Escape user inputs for security
$term = mysqli_real_escape_string($connect, $_REQUEST['term']);
$term = preg_replace("/[^A-Za-z0-9]/", " ", $term);
if (strlen($term) >= 1 && $term !== ' ') {
    // Attempt select query execution
    $sql = "SELECT name FROM cities WHERE name LIKE '%{$term}%'";
    if ($result = mysqli_query($connect, $sql)) {
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_array($result)) {
                echo "<p>" . $row['name'] . "</p>";
            }
            // Close result set
            mysqli_free_result($result);
        }
    } else {
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($connect);
    }
}
?>