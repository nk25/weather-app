
<?php require 'head.php'; ?>
<body>
	<!-- Form to check temperature -->
	<p>Note: This app is working good with these cities delhi,hisar,bengaluru,hyderabad and maybe many more but for some cities the api is not sending the weather condition or temperature to prove this i will also screenshot of the data we get.</p>
<?php require 'form.php'; ?>

</body>
</html>
