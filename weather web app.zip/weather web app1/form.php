  <form action="formsubmit.php" class="" method="post">
        <div class="bgcolor">
            <label class="demo-label">City:</label><br/>
             <div class="search-box">
        <input type="text" name="name" class="form-control" value="<?php if(isset($_COOKIE['mycookie']['search_city'])) { echo $_COOKIE['mycookie']['search_city'] . PHP_EOL;
            } ?>" placeholder="Search Subject..." required=""  autocomplete="off" />
        <div class="result"></div>
    </div>
            <br>
            <label class="demo-label">Your Country:</label><br/>
            <input type="text" name="country" value="<?php if(isset($_COOKIE['mycookie']['searched_country'])) { echo $_COOKIE['mycookie']['searched_country'] . PHP_EOL;
			} ?>" id="txtCountry" class="typeahead" />
            <br>
            <input type="submit" name="submit">
        </div>
    </form>

<!--Funcation to make the autosearch box  -->
<script type="text/javascript">
    $(document).ready(function() {
        $('.search-box input[type="text"]').on("keyup input", function() {
            /* Get input value on change */
            var inputVal = $(this).val();
            var resultDropdown = $(this).siblings(".result");
            if (inputVal.length) {
                $.get("server.php", {
                    term: inputVal
                }).done(function(data) {
                    // Display the returned data in browser
                    resultDropdown.html(data);
                });
            } else {
                resultDropdown.empty();
            }
        });

        // Set search input value on click of result item
        $(document).on("click", ".result p", function() {
            $(this).parents(".search-box").find('input[type="text"]').val($(this).text());
            $(this).parent(".result").empty();
        });
    });
</script>  