<?php
	session_start();
	$connect= mysqli_connect("localhost", "root", "");
	if (!$connect) {
		echo "Connection Failed";
	}else{
		mysqli_select_db($connect, "weather");
	}

 ?>